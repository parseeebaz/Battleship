#include "createboard.h"

using namespace std;

int main(int argc, char* argv[]) {
  createBoards(argc, argv);
  return 0;
}